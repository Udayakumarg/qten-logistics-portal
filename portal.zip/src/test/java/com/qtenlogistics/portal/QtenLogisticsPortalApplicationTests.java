package com.qtenlogistics.portal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QtenLogisticsPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
