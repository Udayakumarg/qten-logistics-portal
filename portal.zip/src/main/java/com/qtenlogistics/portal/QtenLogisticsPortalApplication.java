package com.qtenlogistics.portal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QtenLogisticsPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(QtenLogisticsPortalApplication.class, args);
	}

}
